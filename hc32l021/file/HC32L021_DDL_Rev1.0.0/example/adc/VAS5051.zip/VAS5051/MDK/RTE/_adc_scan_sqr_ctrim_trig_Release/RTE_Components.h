
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'adc_scan_sqr_ctrim_trig' 
 * Target:  'adc_scan_sqr_ctrim_trig_Release' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "hc32l021.h"



#endif /* RTE_COMPONENTS_H */
